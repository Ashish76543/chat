import { io } from "socket.io-client";
import React, { useEffect, useState } from "react";
import axios from "axios";
import socket from "./Socket"; // Ensure this is initialized correctly

function MainPage(props) {
  const { user: m, recep: n, send: o} = props;
  const p=props.receiver;
  
  const [message, setMessage] = useState("");
  const [total, setTotal] = useState([]);
  const [chatNo, setChatNo] = useState(0);

  function handleChange(event) {
    setMessage(event.target.value);
  }

  const submit = async function () {
    
    const unsentMessages = JSON.parse(localStorage.getItem("unsentMessages")) || [];
    const newMessage = { message, user:m,sender:p, idr:n, ids:o };

    unsentMessages.push(newMessage);
    localStorage.setItem("unsentMessages", JSON.stringify(unsentMessages));

    socket.emit("private-message", newMessage);
    setMessage("");
  };

  useEffect(() => {
    // Send unsent messages when the component mounts

    const handleTotal=async function()
    {
      var result=await axios.post("http://localhost:3000/entireSet",{sender:m,receiver:p});
      var resultSet=result.data;
      setTotal(resultSet);
    } 
    handleTotal();
    const chatNumSet=async function(){
      var result=await axios.post("http://localhost:3000/chatSet",{sender:m,receiver:p});
      setChatNo(result.data.chatNo);


    }
    chatNumSet();
    const sendUnsentMessages = async () => {
      const savedMessages = JSON.parse(localStorage.getItem("unsentMessages")) || [];

      if (savedMessages.length > 0) {
        try {
          await axios.post("http://localhost:3000/store-messages", { messages: savedMessages });

          // Clear stored messages after successful send
          localStorage.removeItem("unsentMessages");
        } catch (error) {
          console.error("Error storing messages:", error);
        }
      }
    };

    sendUnsentMessages();
  }, []);

  useEffect(() => {

    socket.emit("id", "none");

    socket.on("result", (message) => {
      setTotal((prev) => [...prev, message]);
    });

    return () => {
      socket.off("result");
    };
  }, []);

  // Interval to send unsent messages every 10 seconds
  useEffect(() => {
    const interval = setInterval(async () => {
      const savedMessages = JSON.parse(localStorage.getItem("unsentMessages")) || [];

      if (savedMessages.length > 0) {
        try {
          await axios.post("http://localhost:3000/store-messages", { messages: savedMessages });

          // Clear stored messages after successful send
          localStorage.removeItem("unsentMessages");
        } catch (error) {
          console.error("Error storing messages:", error);
        }
      }
    }, 3000); // 10 seconds

    return () => clearInterval(interval); // Cleanup interval on component unmount
  }, []);

  return (
    <div>
      <input type="text" value={message} placeholder="Enter message" onChange={handleChange} />
      <button onClick={submit}>Submit</button>
      <ul>
        {total.length > 0 ? total.map((x, index) => <li key={index}>Message {chatNo}: {x}</li>) : <p>No messages</p>}
      </ul>
    </div>
  );
}

export default MainPage;
