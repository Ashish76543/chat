import MainPage from "./MainPage.jsx"
import socket from "./Socket";
import React from "react"
import axios from "axios"
var q=0
function App()
{  
  var [a,seta]=React.useState("");
  var [b,setb]=React.useState("");
  var [recep,setrecep]=React.useState("");
  var [send,setSend]=React.useState("");
  var [check,setCheck]=React.useState(false);
  var [messageReloader,setMessageReloader]=React.useState(q)
 function handleChangeA (event)
  {
     var x=event.target.value;
     seta(x);
  }
  function handleChangeB (event)
  {
     var x=event.target.value;
     setb(x);
  }
  const logina=async function ()
  {
      
     
      var result=await axios.post("http://localhost:3000/checkuser",{data:a,sid:socket.id,rname:b});
      setSend(result.data)
      
  }
  const loginb=async function ()
  {
      
     
      var result=await axios.post("http://localhost:3000/checkuser/recipient",{rname:b});
      setrecep(result.data);
      setMessageReloader(q++);
      setCheck(true);
     
      
  }

  return(
    <div>
      <input type="text" value={a} onChange={handleChangeA} placeholder="enter the username"></input>
      <button onClick={logina}>Submit</button>
      <input type="text" value={b} onChange={handleChangeB} placeholder="enter the recipient"></input>
      <button onClick={loginb}>Submit recipient</button>
      {check==true&&<MainPage key={recep} user={a} send={send} recep={recep} receiver={b} mes={messageReloader}></MainPage>}
    </div>
  )
}
export default App;