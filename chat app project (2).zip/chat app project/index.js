import express from "express";
import bodyParser from "body-parser";
import cors from "cors";
import pg from "pg";
import axios from "axios";
import http from 'http';
import { Server }from "socket.io";
const app=express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
      origin: "http://localhost:5173", // Allow only React Vite frontend
      methods: ["GET","POST"]
    }
  });

  const db=new pg.Client({
    user:"postgres",
    password:"root",
    host:"localhost",
    port:5432,
    database:"users"
  })
  db.connect();
app.use(cors());
app.use(express.json());

io.on("connection",(socket)=>{
    socket.on("message",(message)=>{
        io.emit("result",message);
    })
    socket.on("id",(x)=>{
        console.log(socket.id)
    })
    socket.on("private-message",({message,user,idr,ids})=>{
        io.to(idr).emit("result",message)
        io.to(ids).emit("result",message)


        
    })
})

app.post("/checkuser",async (req,res)=>{
var x=req.body.data;
var y=req.body.sid

var result=await db.query("select count(*) as count from users where name=$1",[x]);
if(result.rows[0].count==0)
{
   await db.query("insert into users (name,socketid) values ($1,$2)",[x,y]);
    console.log(x);
    console.log(y);
   
}
else{
    await db.query("update users set socketid=$1 where name=$2",[y,x])
   
    
}
var l=await db.query("select socketid from users where name=$1",[x]);
res.json(l.rows[0].socketid);

})

app.post("/checkuser/recipient",async (req,res)=>{
    var z=req.body.rname;
    console.log("recep name"+z);
    var r= await db.query("select socketid from users where name=$1",[z])
    
    res.json(r.rows[0].socketid);

})

app.post("/store-messages", async (req, res) => {
    try {
      var messages = req.body.messages; 
  
      if (!messages || messages.length === 0) {
        return res.status(400).json({ error: "No messages to store" });
      }
  
      
      await Promise.all(
        messages.map(async (z) => {
          await db.query(
            "INSERT INTO messages (message, sender, receiver) VALUES ($1, $2, $3)",
            [z.message, z.user, z.sender] 
          );
        })
      );
  
      res.json({ status: "success", message: "Messages stored successfully" });
    } catch (error) {
      console.error("Database error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });

  app.post("/entireSet",async(req,res)=>{
   var x=req.body.sender;
   var y=req.body.receiver;
    var result=await db.query("select message from messages where (sender = $1 AND receiver = $2) OR (sender = $2 AND receiver = $1) ORDER BY id ASC",[x,y]);
    var m=[];
    m=result.rows.map(x=>x.message)
    res.json(m)
    
  })

  app.post("/chatSet",async(req,res)=>{
    console.log("working")
    var x=req.body.sender;
    var y=req.body.receiver;
    var result=await db.query("select count(*) as data from chatNo where (sender=$1 and receiver=$2) or (sender=$2 and receiver=$1)",[x,y]);
    if(Number(result.rows[0].data)==0)
    {
      await db.query("insert into chatNo (sender,receiver) values ($1,$2)",[x,y]);
    }
    result=await db.query("select id from chatNo where (sender=$1 and receiver=$2) or (sender=$2 and receiver=$1)",[x,y]);
    console.log(result.rows[0].id);
    res.json({chatNo:result.rows[0].id});
  }
)
app.post("/checkSocket",async(req,res)=>{
  var x=req.body.p;
  var re=await db.query("select socketid from users where name=$1",[x]);
  res.json({z:re.rows[0].socketid});
})
  
server.listen(3000,()=>{
    console.log("working");
})

